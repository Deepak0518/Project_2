<!-- Main Footer -->
    <footer class="main-footer">
		<div class="auto-container">
        	<!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">
					
					<!--Footer Column-->
					<div class="footer-column col-lg-4 col-md-6 col-sm-12">
						<div class="footer-widget logo-widget">
							<div class="logo">
								<a href="index.php"><img src="images/logo.png" alt=""  style="height:100px; margin-top:-82px"/></a>
							</div>
							<div class="text">Smaahira consultant is a name to reckon within consulting. Our major focus is on 100% customer service and provide consulting solutions across the globe, by maintaining work confidential, excellent mapping, quick turnaround time, Accurate assessment, wide networking across all industries.</div>
							<ul class="social-icons">
								<li class="facebook"><a href="https://www.facebook.com/smaahiraconsultant/"><span class="fab fa-facebook-f"></span></a></li>
								<li class="twitter"><a href="#"><span class="fab fa-twitter"></span></a></li>
								<li class="vimeo"><a href="#"><span class="fab fa-vimeo-v"></span></a></li>
								<li class="linkedin"><a href="#"><span class="fab fa-linkedin-in"></span></a></li>
							</ul>
						</div>
					</div>
					
					<!--Footer Column-->
					<div class="footer-column col-lg-3 col-md-6 col-sm-12">
						<div class="footer-widget links-widget">
							<h2>Quick Link</h2>
							<div class="widget-content">
								<ul class="list">
									<li><a href="index.php">Home</a></li>
									<li><a href="about.php">About us</a></li>
									<li><a href="expertise.php">Expertise</a></li>
									<li><a href="services.php">Services</a></li>
									<li><a href="contact.php">Contact Us</a></li>
								</ul>
							</div>
						</div>
					</div>
					
					<!--Footer Column-->
					<div class="footer-column col-lg-5 col-md-12 col-sm-12">
						<div class="footer-widget newsletter-widget">
							<h2>Maps</h2>
							<div class="text"></div>
							<!-- Newsletter Form -->
							<div class="newsletter-form">
								<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d117331.54416086066!2d72.5755070685498!3d23.22085195075699!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395c2b987c6d6809%3A0xf86f06a7873e0391!2sGandhinagar%2C%20Gujarat!5e0!3m2!1sen!2sin!4v1599058316232!5m2!1sen!2sin" width="100%" height="250" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
							</div>
						</div>
					</div>

				</div>
			</div>
			
			<!-- Footer Bottom -->
			<div class="footer-bottom">
				<div class="clearfix">
					<div class="pull-left">
						<div class="copyright"> &copy; 2020 All Right Reserved</div>
					</div>
					
				</div>
			</div>
			
		</div>
	</footer>
	<!-- End Main Footer -->